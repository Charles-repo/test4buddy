package edu.rice.comp504.controller;

import com.google.gson.Gson;
import com.google.gson.JsonParser;

import static spark.Spark.*;

/**
 * The SimpleShapesController is responsible for interfacing between the view and the model.  The model will determine
 * how shape objects are created.  The view is the browser.  The browser has a canvas that renders the shapes.
 * The controller interacts with the view by receiving REST get requests for various shapes.
 */
public class SimpleShapesController {

    /**
     *  Entry point into the program.
     * @param args  The arguments
     */
    public static void main(String[] args) {
        staticFiles.location("/public");
        Gson gson = new Gson();

        // GET request to create a new circle.  Controller will need to contact the model to service the request
        get("/shape/circle", (request, response) -> {
            // TODO: Need to create a circle object and then return the JSON version back to the view
            return gson.toJson("A circle");
        });

        // GET request to create a new triangle.  Controller will need to contact the model to service the request
        get("/shape/triangle", (request, response) -> {
            // TODO: Need to create a triangle object and then return the JSON version back to the view
            return gson.toJson("A triangle");
        });

        post("/canvas/dims", (request, response) -> {
            // TODO: retrieve canvas dimensions
            return gson.toJson("Canvas dims");
        });

    }
}
