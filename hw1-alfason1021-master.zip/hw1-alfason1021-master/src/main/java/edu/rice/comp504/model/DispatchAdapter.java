package edu.rice.comp504.model;

import java.awt.Point;
import java.util.ArrayList;

/**
 * The dispatch adapter holds all the shapes. It is responsible for communicating with the model
 * when there is a state change requiring an update to all the shapes.  The controller will
 * pass the JSON representation of the dispatch adapter to the view.
 */
public class DispatchAdapter {
    private static Point dims;
    private ArrayList<AShape> shapes;

    /**
     * Constructor call.
     */
    public DispatchAdapter() {

    }

    /**
     * Get the canvas dimensions.
     * @return The canvas dimensions
     */
    public static Point getCanvasDims() {
        return dims;
    }

    /**
     * Set the canvas dimensions.
     * @param d The canvas width (x) and height (y).
     */
    public static void setCanvasDims(Point d) {
        dims = d;
    }

    /**
     * Call the update method on all the shapes.
     */
    public ArrayList<AShape> updateShapes() {
        return null;
    }

    /**
     *  Add a shape.
     * @param type  The type of shape to add
     * @return A ball
     */
    public AShape addShape(String type) {
        return null;
    }

    /**
     * Remove all shapes.
     */
    public ArrayList<AShape> removeShapes() {
        return null;
    }
}
